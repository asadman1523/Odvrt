# Odvrt

Odvrt 全名為 Older driver video rename tool 老司機影片改名工具，能搜尋檔案番號加入片名並下載縮圖

# 安裝 Install

1. 安裝Python 3.9 最後記得勾選Add To PATH
1. 到Release把zip下載下來並解壓縮
   1. https://github.com/asadman1523/odvrt/releases
1. 到資料夾底下打開 Terminal 輸入 pip install -r requirements.txt
1. 到資料夾底下打開 Terminal 輸入 python odvrt.py

# 使用方法 How to use
老司機應該都會吧，把檔案拉進去點執行就可以了，有任何問題可以開issue給我，平日要上班不一定會馬上回
![](how_to_use.gif)

# 貢獻 Attribute
JackWu的肝
<div>Icons made by <a href="https://www.flaticon.com/authors/roundicons" title="Roundicons">Roundicons</a> from <a href="https://www.flaticon.com/" title="Flaticon">www.flaticon.com</a></div>


# Lisense
Copyright 2020 JackWu

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

   http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
